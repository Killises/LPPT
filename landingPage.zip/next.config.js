module.exports = { reactStrictMode: true };
